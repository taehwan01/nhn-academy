package com.nhnacademy;

public interface Human {
    public String getName();
}
