package com.nhnacademy;

public enum Category {
    FRUIT,
    VEGETABLE,
    MEAT,
    FISH,
    DAIRY
}
