package com.nhnacademy;

import java.net.ServerSocket;
import java.net.Socket;
import java.text.ParseException;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Options;

public class Main {
    public static void main(String[] args) {
        Options options = new Options();

        options.addOption("l", true, "Listen");

        CommandLineParser parser = new DefaultParser();
        try {
            CommandLine commandLine = parser.parse(options, args);
            int port = commandLine.hasOption("p") ? Integer.parseInt(commandLine.getOptionValue("p")) : 1234;

            try (ServerSocket serverSocket = new ServerSocket(1234);
                    Socket socket = serverSocket.accept()) {
                System.out.println("SERVER OPENED");
                Thread thread = new Thread(
                        new Netcat(System.in, System.out, socket.getInputStream(), socket.getOutputStream()));
                thread.start();
                thread.join();
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        } catch (org.apache.commons.cli.ParseException e) {
        }
    }
}
